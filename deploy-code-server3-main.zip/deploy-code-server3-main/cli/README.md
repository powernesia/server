# dcs-cli

Provision a code-server instance from your terminal.

## Development

```console
git clone git@github.com:cdr/deploy-code-server.git
cd deploy-code-server/cli
npm install && npm run build:watch

# in another session:
node bin/index.js
```
