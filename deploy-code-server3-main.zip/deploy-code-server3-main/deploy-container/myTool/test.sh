#!/bin/bash

echo "This is a demo tool that could be brought into the code-server workspace"